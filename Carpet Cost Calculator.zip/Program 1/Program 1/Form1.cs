﻿// N4780
// Due 2/12/2019
// Program 1
// CIS 199 - 75
// This program is meant to estimate the cost of carpet installation in a given room or number of rooms.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalcEstaBtn_Click(object sender, EventArgs e)
        {
            //Declaring Variables being used
            double WidthIn;
            double LengthIn;
            double PriceIn;
            int LayersIn;
            int FirstRoomIn;
            double SqYardsNeeded;
            double CarpetCost;
            double PaddingCost;
            double LaborCost;
            double TotalCost;

            //Declaring all of my input variables to be read
            WidthIn = double.Parse(WidthIntxt.Text);
            LengthIn = double.Parse(LengthIntxt.Text);
            PriceIn = double.Parse(PriceIntxt.Text);
            LayersIn = int.Parse(LayersIntxt.Text);
            FirstRoomIn = int.Parse(FirstRoomIntxt.Text);

            // Formulas for the output calculating all of required measurements and cost
            SqYardsNeeded = WidthIn * LengthIn / 9;
            CarpetCost = SqYardsNeeded * PriceIn * 1.1;
            PaddingCost = LayersIn * SqYardsNeeded * 2.75 * 1.1;
            LaborCost =  SqYardsNeeded * 4.50 + 100;
            TotalCost = CarpetCost + PaddingCost + LaborCost;

            //Assigning the output labels to the proper values
            SqYardsNeededOutLbl.Text = $"{SqYardsNeeded:F1}";
            CarpetCostOutLbl.Text = $"{CarpetCost:C2}";
            PaddingCostOutLbl.Text = $"{PaddingCost:C2}";
            LaborCostOutLbl.Text = $"{LaborCost:C2}";
            TotalCostOutLbl.Text = $"{TotalCost:C2}";

        }
    }
}
