﻿namespace Program_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WidthIntxt = new System.Windows.Forms.TextBox();
            this.FirstRoomIntxt = new System.Windows.Forms.TextBox();
            this.LayersIntxt = new System.Windows.Forms.TextBox();
            this.PriceIntxt = new System.Windows.Forms.TextBox();
            this.LengthIntxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.CalcEstaBtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.TotalCostOutLbl = new System.Windows.Forms.Label();
            this.LaborCostOutLbl = new System.Windows.Forms.Label();
            this.SqYardsNeededOutLbl = new System.Windows.Forms.Label();
            this.PaddingCostOutLbl = new System.Windows.Forms.Label();
            this.CarpetCostOutLbl = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // WidthIntxt
            // 
            this.WidthIntxt.Location = new System.Drawing.Point(251, 67);
            this.WidthIntxt.Name = "WidthIntxt";
            this.WidthIntxt.Size = new System.Drawing.Size(100, 20);
            this.WidthIntxt.TabIndex = 0;
            // 
            // FirstRoomIntxt
            // 
            this.FirstRoomIntxt.Location = new System.Drawing.Point(251, 266);
            this.FirstRoomIntxt.Name = "FirstRoomIntxt";
            this.FirstRoomIntxt.Size = new System.Drawing.Size(100, 20);
            this.FirstRoomIntxt.TabIndex = 1;
            // 
            // LayersIntxt
            // 
            this.LayersIntxt.Location = new System.Drawing.Point(251, 215);
            this.LayersIntxt.Name = "LayersIntxt";
            this.LayersIntxt.Size = new System.Drawing.Size(100, 20);
            this.LayersIntxt.TabIndex = 2;
            // 
            // PriceIntxt
            // 
            this.PriceIntxt.Location = new System.Drawing.Point(251, 162);
            this.PriceIntxt.Name = "PriceIntxt";
            this.PriceIntxt.Size = new System.Drawing.Size(100, 20);
            this.PriceIntxt.TabIndex = 3;
            // 
            // LengthIntxt
            // 
            this.LengthIntxt.Location = new System.Drawing.Point(251, 114);
            this.LengthIntxt.Name = "LengthIntxt";
            this.LengthIntxt.Size = new System.Drawing.Size(100, 20);
            this.LengthIntxt.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Max width of room (in feet):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(52, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Max length of room (in feet):";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(52, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(130, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "Carpet Price (per sq. feet):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(52, 222);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(174, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Layers of Padding desired (up to 2):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(52, 269);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(193, 13);
            this.label5.TabIndex = 9;
            this.label5.Text = "Is the the first room? (1 = YES, 0 = NO):";
            // 
            // CalcEstaBtn
            // 
            this.CalcEstaBtn.Location = new System.Drawing.Point(185, 337);
            this.CalcEstaBtn.Name = "CalcEstaBtn";
            this.CalcEstaBtn.Size = new System.Drawing.Size(75, 23);
            this.CalcEstaBtn.TabIndex = 10;
            this.CalcEstaBtn.Text = "Calculate";
            this.CalcEstaBtn.UseVisualStyleBackColor = true;
            this.CalcEstaBtn.Click += new System.EventHandler(this.CalcEstaBtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(462, 70);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 13);
            this.label6.TabIndex = 11;
            this.label6.Text = "Sq. Yards Needed:";
            // 
            // TotalCostOutLbl
            // 
            this.TotalCostOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.TotalCostOutLbl.Location = new System.Drawing.Point(642, 269);
            this.TotalCostOutLbl.Name = "TotalCostOutLbl";
            this.TotalCostOutLbl.Size = new System.Drawing.Size(73, 17);
            this.TotalCostOutLbl.TabIndex = 12;
            // 
            // LaborCostOutLbl
            // 
            this.LaborCostOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LaborCostOutLbl.Location = new System.Drawing.Point(642, 218);
            this.LaborCostOutLbl.Name = "LaborCostOutLbl";
            this.LaborCostOutLbl.Size = new System.Drawing.Size(73, 17);
            this.LaborCostOutLbl.TabIndex = 13;
            // 
            // SqYardsNeededOutLbl
            // 
            this.SqYardsNeededOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.SqYardsNeededOutLbl.Location = new System.Drawing.Point(642, 70);
            this.SqYardsNeededOutLbl.Name = "SqYardsNeededOutLbl";
            this.SqYardsNeededOutLbl.Size = new System.Drawing.Size(73, 17);
            this.SqYardsNeededOutLbl.TabIndex = 14;
            // 
            // PaddingCostOutLbl
            // 
            this.PaddingCostOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PaddingCostOutLbl.Location = new System.Drawing.Point(642, 162);
            this.PaddingCostOutLbl.Name = "PaddingCostOutLbl";
            this.PaddingCostOutLbl.Size = new System.Drawing.Size(73, 16);
            this.PaddingCostOutLbl.TabIndex = 15;
            // 
            // CarpetCostOutLbl
            // 
            this.CarpetCostOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.CarpetCostOutLbl.Location = new System.Drawing.Point(642, 117);
            this.CarpetCostOutLbl.Name = "CarpetCostOutLbl";
            this.CarpetCostOutLbl.Size = new System.Drawing.Size(73, 17);
            this.CarpetCostOutLbl.TabIndex = 16;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(462, 269);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 17;
            this.label12.Text = "Total Cost:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(462, 218);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(61, 13);
            this.label13.TabIndex = 18;
            this.label13.Text = "Labor Cost:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(462, 165);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(73, 13);
            this.label14.TabIndex = 19;
            this.label14.Text = "Padding Cost:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(462, 117);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(65, 13);
            this.label15.TabIndex = 20;
            this.label15.Text = "Carpet Cost:";
            // 
            // Form1
            // 
            this.AcceptButton = this.CalcEstaBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.CarpetCostOutLbl);
            this.Controls.Add(this.PaddingCostOutLbl);
            this.Controls.Add(this.SqYardsNeededOutLbl);
            this.Controls.Add(this.LaborCostOutLbl);
            this.Controls.Add(this.TotalCostOutLbl);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.CalcEstaBtn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LengthIntxt);
            this.Controls.Add(this.PriceIntxt);
            this.Controls.Add(this.LayersIntxt);
            this.Controls.Add(this.FirstRoomIntxt);
            this.Controls.Add(this.WidthIntxt);
            this.Name = "Form1";
            this.Text = "Carpet Estimator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox WidthIntxt;
        private System.Windows.Forms.TextBox FirstRoomIntxt;
        private System.Windows.Forms.TextBox LayersIntxt;
        private System.Windows.Forms.TextBox PriceIntxt;
        private System.Windows.Forms.TextBox LengthIntxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button CalcEstaBtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label TotalCostOutLbl;
        private System.Windows.Forms.Label LaborCostOutLbl;
        private System.Windows.Forms.Label SqYardsNeededOutLbl;
        private System.Windows.Forms.Label PaddingCostOutLbl;
        private System.Windows.Forms.Label CarpetCostOutLbl;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
    }
}

