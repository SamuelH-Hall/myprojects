﻿namespace Lab_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MEALPRICE = new System.Windows.Forms.Label();
            this.TIPRATE3 = new System.Windows.Forms.Label();
            this.TIPRATE2 = new System.Windows.Forms.Label();
            this.TIPRATE1 = new System.Windows.Forms.Label();
            this.MEDTIPRATEOutLbl = new System.Windows.Forms.Label();
            this.HIGHTIPRATEOutLbl = new System.Windows.Forms.Label();
            this.LOWTIPRATEOutLbl = new System.Windows.Forms.Label();
            this.TTLMEALPRICEtxt = new System.Windows.Forms.TextBox();
            this.CalcTipBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // MEALPRICE
            // 
            this.MEALPRICE.AutoSize = true;
            this.MEALPRICE.Location = new System.Drawing.Point(35, 41);
            this.MEALPRICE.Name = "MEALPRICE";
            this.MEALPRICE.Size = new System.Drawing.Size(124, 13);
            this.MEALPRICE.TabIndex = 0;
            this.MEALPRICE.Text = "Enter total price of meal :";
            this.MEALPRICE.Click += new System.EventHandler(this.label1_Click);
            // 
            // TIPRATE3
            // 
            this.TIPRATE3.AutoSize = true;
            this.TIPRATE3.Location = new System.Drawing.Point(129, 180);
            this.TIPRATE3.Name = "TIPRATE3";
            this.TIPRATE3.Size = new System.Drawing.Size(33, 13);
            this.TIPRATE3.TabIndex = 1;
            this.TIPRATE3.Text = "20 %:";
            // 
            // TIPRATE2
            // 
            this.TIPRATE2.AutoSize = true;
            this.TIPRATE2.Location = new System.Drawing.Point(129, 135);
            this.TIPRATE2.Name = "TIPRATE2";
            this.TIPRATE2.Size = new System.Drawing.Size(33, 13);
            this.TIPRATE2.TabIndex = 2;
            this.TIPRATE2.Text = "18 %:";
            // 
            // TIPRATE1
            // 
            this.TIPRATE1.AutoSize = true;
            this.TIPRATE1.Location = new System.Drawing.Point(129, 90);
            this.TIPRATE1.Name = "TIPRATE1";
            this.TIPRATE1.Size = new System.Drawing.Size(33, 13);
            this.TIPRATE1.TabIndex = 3;
            this.TIPRATE1.Text = "15 %:";
            // 
            // MEDTIPRATEOutLbl
            // 
            this.MEDTIPRATEOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.MEDTIPRATEOutLbl.Location = new System.Drawing.Point(201, 128);
            this.MEDTIPRATEOutLbl.Name = "MEDTIPRATEOutLbl";
            this.MEDTIPRATEOutLbl.Size = new System.Drawing.Size(97, 20);
            this.MEDTIPRATEOutLbl.TabIndex = 4;
            // 
            // HIGHTIPRATEOutLbl
            // 
            this.HIGHTIPRATEOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.HIGHTIPRATEOutLbl.Location = new System.Drawing.Point(201, 175);
            this.HIGHTIPRATEOutLbl.Name = "HIGHTIPRATEOutLbl";
            this.HIGHTIPRATEOutLbl.Size = new System.Drawing.Size(97, 18);
            this.HIGHTIPRATEOutLbl.TabIndex = 5;
            this.HIGHTIPRATEOutLbl.Click += new System.EventHandler(this.TIPRATE3Out_Click);
            // 
            // LOWTIPRATEOutLbl
            // 
            this.LOWTIPRATEOutLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.LOWTIPRATEOutLbl.Location = new System.Drawing.Point(201, 83);
            this.LOWTIPRATEOutLbl.Name = "LOWTIPRATEOutLbl";
            this.LOWTIPRATEOutLbl.Size = new System.Drawing.Size(97, 20);
            this.LOWTIPRATEOutLbl.TabIndex = 6;
            // 
            // TTLMEALPRICEtxt
            // 
            this.TTLMEALPRICEtxt.Location = new System.Drawing.Point(201, 41);
            this.TTLMEALPRICEtxt.Name = "TTLMEALPRICEtxt";
            this.TTLMEALPRICEtxt.Size = new System.Drawing.Size(97, 20);
            this.TTLMEALPRICEtxt.TabIndex = 7;
            // 
            // CalcTipBtn
            // 
            this.CalcTipBtn.Location = new System.Drawing.Point(146, 224);
            this.CalcTipBtn.Name = "CalcTipBtn";
            this.CalcTipBtn.Size = new System.Drawing.Size(89, 26);
            this.CalcTipBtn.TabIndex = 8;
            this.CalcTipBtn.Text = "Calculate Tip";
            this.CalcTipBtn.UseVisualStyleBackColor = true;
            this.CalcTipBtn.Click += new System.EventHandler(this.CalcTipBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 285);
            this.Controls.Add(this.CalcTipBtn);
            this.Controls.Add(this.TTLMEALPRICEtxt);
            this.Controls.Add(this.LOWTIPRATEOutLbl);
            this.Controls.Add(this.HIGHTIPRATEOutLbl);
            this.Controls.Add(this.MEDTIPRATEOutLbl);
            this.Controls.Add(this.TIPRATE1);
            this.Controls.Add(this.TIPRATE2);
            this.Controls.Add(this.TIPRATE3);
            this.Controls.Add(this.MEALPRICE);
            this.Name = "Form1";
            this.Text = "Lab 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MEALPRICE;
        private System.Windows.Forms.Label TIPRATE3;
        private System.Windows.Forms.Label TIPRATE2;
        private System.Windows.Forms.Label TIPRATE1;
        private System.Windows.Forms.Label MEDTIPRATEOutLbl;
        private System.Windows.Forms.Label HIGHTIPRATEOutLbl;
        private System.Windows.Forms.Label LOWTIPRATEOutLbl;
        private System.Windows.Forms.TextBox TTLMEALPRICEtxt;
        private System.Windows.Forms.Button CalcTipBtn;
    }
}

