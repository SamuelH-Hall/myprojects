﻿// Grading ID: R7637
// Lab 2
// CIS 199-01
// Due 2/3/2020
// This lab is intended to calculate tips of a meal price for 15%, 18%, and 20% tip rates.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void TIPRATE3Out_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void CalcTipBtn_Click(object sender, EventArgs e)
        {
            double TTLMEALPRICE; //meal price
            double LOWTIPRATEOut; // 15% tip
            double MEDTIPRATEOut; // 18% tip
            double HIGHTIPRATEOut; // 20% tip

            TTLMEALPRICE = double.Parse(TTLMEALPRICEtxt.Text); //Reads the total price of meal for equation

            LOWTIPRATEOut = TTLMEALPRICE * 0.15; //Calculates 15% tip
            MEDTIPRATEOut = TTLMEALPRICE * 0.18; //Calculates 18% tip
            HIGHTIPRATEOut = TTLMEALPRICE * 0.20; // Calculates 20% tip

            LOWTIPRATEOutLbl.Text = $"{LOWTIPRATEOut:C2}"; //displays answer of 15% tip
            MEDTIPRATEOutLbl.Text = $"{MEDTIPRATEOut:C2}"; //displays answer of 18% tip
            HIGHTIPRATEOutLbl.Text = $"{HIGHTIPRATEOut:C2}"; //displays answer of 20% tip

        }


        }
    }
 