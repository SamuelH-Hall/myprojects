#Grading ID: D2479
#Program 2
#CIS 443
#Due Date:10/12/2020
#The objective of this program is to declare a list of values and use the built
#functions for statistics, numpy, and seaborn to find certain statistic data out
#and build a graph featuring a counter that counts the unique values of the list.

#importing the outside methods that are used in the program
import statistics as stats #used to find the statistics of the list
import seaborn as sns #used to create the graph required
import numpy #used to count value frequencies within the list

#declaring the list
surveyResults = [1, 2, 5, 4, 3, 5, 9, 1, 3, 3, 1, 4, 3, 3, 3, 2, 3, 3, 2, 5]

#declaring where the max and min values of the list are to start
maxRes = surveyResults[0]
minRes = surveyResults[0]

#the for loop where the operations will be ran to find all the required statistics
#of the list
for i in range(0, len(surveyResults),1):
    maxRes = max(maxRes, surveyResults[i])#finds the max value in the list
    minRes = min(minRes, surveyResults[i])#finds the min value in the list
    averageRes = stats.mean(surveyResults)#does the statistical mean for the list
    rangeRes = maxRes - minRes#manual equation to find the range of the values
    medRes = stats.median(surveyResults)#find the median of the list
    moRes = stats.mode(surveyResults) #find the mode of the list
    varRes = stats.variance(surveyResults)#find the variance of the list
    sdRes = stats.stdev(surveyResults)#finds the standard deviation of the list
    
print("Max:", maxRes) #prints the max value
print("Min:", minRes) #prints the min value
print("Range:", rangeRes) #prints the range of the given list of values
print("Mean:", averageRes) #prints the average of all the values
print("Median:", medRes) #prints the median of the list of given values
print("Mode:", moRes) #prints the mode of the list of values
print("Variance:", varRes) #prints to the variance of the list
print("Standard Deviation:", sdRes) #prints the standard deviation of the list

#Values of the list are counted in the code below
values, frequencies = numpy.unique(surveyResults, return_counts=True)

title = "Survey of Cafeteria Food" #The title of the bar graph


sns.set_style('whitegrid')#this is where the style of the background of the graph is chosen

axes = sns.barplot(x=values, y=frequencies, palette='gray')
# this sets the axes of the graph with the variables
#from the counter that was set up to count the unique values
#x being values and y being frequencies
#sets the color of the bars in the greaph as well

axes.set_title(title)#title of the graph being set

axes.set(xlabel='Survey Value', ylabel='Frequency')#labels for the axes

axes.set_ylim(top=max(frequencies) * 1.5)#this sets the scales for the y axis
#took the max frequencies and mulitplied that value by 1.5 to easily see the data

#this is where the graphn is put together and formatted through a for loop
for bar, frequency in zip(axes.patches, frequencies):
    text_x = bar.get_x() + bar.get_width() / 2.0#formats the text of the x bars
    text_y = bar.get_height()#the bar height will be the text value here
    text = f'{frequency:,}\n{frequency / len(surveyResults):.00%}'
    #this is where the output data is declared for the information to be displayed in the bar chart
    axes.text(text_x, text_y, text, fontsize=10, ha="center" , va='bottom')
    #formats the font size and alignment of the text on the chart
